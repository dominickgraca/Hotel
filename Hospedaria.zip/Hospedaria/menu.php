<?php include_once('server/session.php'); ?>

      <!-- Small boxes (Stat box) -->
      <div class="row">
        <a href="#" class="small-box-footer" id="cliente">
          <div class="col-lg-3 col-xs-6">
            <!-- small box -->
            <div class="small-box bg-aqua">
              <div class="inner" id="members">
                <h3>0<sup style="font-size: 20px"></sup></h3>
                <p>CLIENTES</p>
              </div>
              <div class="icon">
                <i class="fa fa-users"></i>
              </div>            
            </div>
          </div>
        </a>
        <!-- ./col -->

       <a href="#" class="small-box-footer" id="ocupado">
        <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-red ">
            <div class="inner" id="reserved">
              <h3>0</h3>
              <p>QUARTOS OCUPADOS</p>
            </div>
            <div class="icon">
              <i class="fa fa-building"></i>
            </div>
          </div>
        </div>
</a>
        <a href="#" class="small-box-footer" id="vagos"> <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-green">
            <div class="inner" id="free_rooms">
              <h3>0</h3>
              <p>QUARTOS VAGOS</p>
            </div>
            <div class="icon">
              <i class="fa fa-building"></i>
            </div>           
          </div>
        </div> </a>

   <?php
if ($_SESSION['permition']=='admin') {

print'
       <a href="#" class="small-box-footer" id="users_"> <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-yellow">
            <div class="inner">
              <h3>0<sup style="font-size: 20px"></sup></h3>
              <p>USUÁRIO</p>
            </div>
            <div class="icon">
              <i class="fa fa-users"></i>
            </div>            
          </div>
        </div></a>

    ';
}
?>
</div>

<!-- jQuery 2.2.3 -->
<script src="plugins/jQuery/jquery-2.2.3.min.js"></script>
<!-- Bootstrap 3.3.7 -->
<script src="bootstrap/js/bootstrap.min.js"></script>
<!-- Select2 -->
<script type="text/javascript" src="js/pagination.js"></script>

<script type="text/javascript" src="js/scripts.js"></script>




