<?php include('header.php'); ?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1> 
      <ol class="breadcrumb">
        <li><a href="dashboard.php"><i class="fa fa-home"></i> HOME</a></li>
        <li class="active">EDITANDO PACIENTES</a></li>
      </ol>
  </h1>

    </section>

  <div class="tab-content">

<div id="register_news" class="tab-pane fade in active">

    <section class="content">
      <div class="row">
        <!-- left column -->
        <div class="col-md-12">


 <div id="response" class="alert alert-success" style="display:none;">
  <div class="message"></div>
  
</div>
<div class="col-md-12"> 
  <!-- general form elements -->
          <div class="box " >
            <div class="box-header with-border" style="background-color:#00a65a">
              <h3 class="box-title" style="color:white"> EDITANDO DADOS DO PACIENTE </h3>
            </div>
            <!-- /.box-header -->
            <!-- form start -->
            <form  id="form_users" name="form_users" method="post">
            
                    <div class="box-body">

                      <input type="hidden" name="action" value="update_member">
                       <input type="hidden" name="id" value="<?php echo $id; ?>">
                        <div class="col-md-6"> 

                                <div class="form-group">
                                  <label> NOME COMPLETO * </label>
                                  <input type="text" class="form-control required" name="nome" placeholder="NOME COMPLETO" value="<?php echo $nome ?>">
                                </div>
                              
                                <div class="form-group">
                                  <label> IDADE </label>
                                  <input type="text" class="form-control" name="age" placeholder="IDADE" value="<?php echo $age ?>">
                                </div>

                                          <div class="form-group">
                                <label> GENERO *</label>
                                <select name="gender" class="form-control">

                                   <option value="M" <?php if($gender === 'M'){?>selected<?php } ?>>MASCULINO</option>
                                   <option value="F" <?php if($gender === 'F'){?>selected<?php } ?>>FEMENINO</option>
                                
                                </select>
                            </div>

                        </div>

                        <div class="col-md-6">

                              <div class="form-group">
                                  <label> NUMERO DO BILHETE </label>
                                  <input type="text" class="form-control required" name="bi" placeholder="BI" value="<?php echo $bi ?>">
                                </div>


                            <div class="form-group">
                              <label> TEL </label>
                              <input type="text" class="form-control" name="mobile" placeholder="TELEFONE" value="<?php echo $mobile ?>">
                            </div>

                            <div class="form-group">
                                  <label>MORADA </label>
                                  <textarea class="form-control" name="address" placeholder="MORADA"><?php echo $address ?></textarea> 
                            </div>

                        </div>
                   
                             <div class="box-footer">
                                <button type="submit" id="btn_users" class="btn btn-primary pull-right">ACTUALIZAR</button>
                              </div>
                  

                  </div>
                      </div>
                  </div>

                
            </form>
          </div>
        </div>

  
        </div>
        </div>
      </section>
</div>

</div>


</div>


      <div id="delete_activities" class="modal fade">
        <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header" >
          <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
          <center><h4 class="modal-title">Apagar Paciente</h4></center>
          </div>
          <div class="modal-body">

          <center> <p>Tens certesa?</p></center>
         
          </div>
          <div class="modal-footer">
          <button type="button" data-dismiss="modal" class="btn btn-primary" id="delete">Sim</button>
          <button type="button" data-dismiss="modal" class="btn">Não</button>
          </div>
        </div><!-- /.modal-content -->
        </div><!-- /.modal-dialog -->
      </div><!-- /.modal -->

<?php include('footer.php'); ?>