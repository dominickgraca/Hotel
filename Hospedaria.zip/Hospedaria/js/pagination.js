$(document).ready(function(){
	
	$("#cliente").click(function(e){
		e.preventDefault();
		$("#general_contente").html("<h2><center><br><br><br><br><br><br>Por favor aguarde...</center></h2>");
		$("#general_contente").load('members.php');
	});


	$("#dashboard_").click(function(e){
		e.preventDefault();
		$("#general_contente").html("<h2><center><br><br><br><br><br><br>Por favor aguarde...</center></h2>");
		$("#general_contente").load('menu.php');
	});


		$("#perfil").click(function(e){
		e.preventDefault();
		$("#general_contente").html("<h2><center><br><br><br><br><br><br>Por favor aguarde...</center></h2>");
		$("#general_contente").load('profile.php');
	});



	$(".dashboard_").click(function(e){
		e.preventDefault();
		$("#general_contente").html("<h2><center><br><br><br><br><br><br>Por favor aguarde...</center></h2>");
		$("#general_contente").load('menu.php');
	});


	$("#vagos").click(function(e){
		e.preventDefault();
		$("#general_contente").html("<h2><center><br><br><br><br><br><br>Por favor aguarde...</center></h2>");
		$("#general_contente").load('free_rooms.php');
	});

	$("#users_").click(function(e){
		e.preventDefault();
		$("#general_contente").html("<h2><center><br><br><br><br><br><br>Por favor aguarde...</center></h2>");
		$("#general_contente").load('users.php');
	});

	$("#ocupado").click(function(e){
		e.preventDefault();
		$("#general_contente").html("<h2><center><br><br><br><br><br><br>Por favor aguarde...</center></h2>");
		$("#general_contente").load('rooms.php');
	});



	$("#relatorio").click(function(e){
		e.preventDefault();
		$("#general_contente").html("<h2><center><br><br><br><br><br><br>Por favor aguarde...</center></h2>");
		$("#general_contente").load('reports.php');
	});


	
	
	$(document).on('click','.chat_page',function(e){

		e.preventDefault();
			var id = $(this).attr('rel');
		//$.post('server/messages/fetch_chat.php',{id:id});
	
		$("#general_contente").html("<h2> <center> <br><br><br><br><br><br>Por favor aguarde... </center> </h2>");
		$("#general_contente").load('chat.php?id='+id+'');
		
	});	

	$(document).on('click','.select_quarto',function(e){

		e.preventDefault();
			var id = $(this).attr('rel');
		//$.post('server/messages/fetch_chat.php',{id:id});
	
		$("#general_contente").html("<h2> <center> <br><br><br><br><br><br>Por favor aguarde... </center> </h2>");
		$("#general_contente").load('select_rooms.php?id='+id+'');
		
	});	
	

		$(document).on('click','.notification_page',function(e){

		e.preventDefault();
			var id = $(this).attr('rel');
		//$.post('server/messages/fetch_chat.php',{id:id});
	
		$("#general_contente").html("<h2> <center> <br><br><br><br><br><br>loading... </center> </h2>");
		$("#general_contente").load('todo.php');
		
	});	
		
});