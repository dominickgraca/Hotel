var action = "fetch_gallery";

$.post('server/response.php',{action:action}, function(json){
$.each(json.result,function(i,dat){

  $('#pictures_gallerys').append('<li class="last"><a href="#"><img src="images/gallery/'+dat.picture+'" style="width:110px;height:110px" title="'+dat.description+'" /></a></li>'); 
 //$('#pictures_gallerys').scrollTop(1000);

});

},'json');