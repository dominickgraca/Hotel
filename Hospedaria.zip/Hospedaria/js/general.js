$('#report_sale').on('submit', function(e){

		    	e.preventDefault();
          		//var $btn = $("#btn_validate").button("loading");
          		var nome = $('#username').val();
          		var data = $("#data").val();

          		window.location="relatorio.php?data="+data+"&nome="+nome+" ";

});
     