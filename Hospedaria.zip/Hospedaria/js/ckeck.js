$(document).ready(function() {

var user_id =sessionStorage.getItem('m_user_id'); 
	
if(user_id){


var action = "fetch_username";

$.post('../server/response.php',{action:action,id:user_id},function(json){



$.each(json.result,function(i,dat){

       $("#user_name").html(dat.surname);

});




},'json');


// log out function
$('#log_out').click(function(){

     sessionStorage.clear('m_user_id');    
     window.location="../index.html";   

});


}
else{


window.location="../index.html";

}


});