$(document).ready(function() {






$('#username').focus();	

$("#login_form input").keyup(function(){
        $(this).parent().removeClass("has-error"); 
		$("#response").fadeOut("slow");
    });	



$("#form_gallery input").keyup(function(){
        $(this).parent().removeClass("has-error"); 
		$("#response").fadeOut("slow");
    });	

	
$("#form_email input").keyup(function(){
        $(this).parent().removeClass("has-error"); 
		$("#response").fadeOut("slow");
    });	

$("#form_vacance input").keyup(function(){
        $(this).parent().removeClass("has-error"); 
		$("#response").fadeOut("slow");
    });	

$("#form_news_post input").keyup(function(){
        $(this).parent().removeClass("has-error"); 
		$("#response").fadeOut("slow");
    });	

	  // remove time table row 
    $('#class_tables').on('click', ".delete-rows", function(e) {
    	e.preventDefault();
       	$(this).closest('tr').remove();
       updateTotals(this);
	    calculateTotal();
    });
	
	// add new row for time table
    var clon = $('#class_tables tr:last').clone();
    $(".add-rows").click(function(e) {
    	
        e.preventDefault();
        clon.clone().appendTo('#class_tables'); 
        updateTotals(this);
	    calculateTotal();
    });
	

	
	


calculateTotal();
    
    $('#class_tables').on('input', '.calculate', function () {

	    updateTotals(this);
	    calculateTotal();
	});

	$('#invoice_totals').on('input', '.calculate', function () {
	    calculateTotal();
	});

	$('#invoice_product').on('input', '.calculate', function () {
	    calculateTotal();
	});

	$('.remove_vat').on('change', function() {
        calculateTotal();
    });

	function updateTotals(elem) {

        var tr = $(elem).closest('tr'),
            quantity = $('[name="invoice_product_qty[]"]', tr).val(),
	        price = $('[name="invoice_product_price[]"]', tr).val(),
            isPercent = $('[name="invoice_product_discount[]"]', tr).val().indexOf('%') > -1,
            percent = $.trim($('[name="invoice_product_discount[]"]', tr).val().replace('%', '')),
	        subtotal = parseInt(quantity) * parseFloat(price);

        if(percent && $.isNumeric(percent) && percent !== 0) {
            if(isPercent){
                subtotal = subtotal + ((parseFloat(percent) / 100) * subtotal);
            } else {
                subtotal = subtotal + parseFloat(percent);
            }
        } else {
            $('[name="invoice_product_discount[]"]', tr).val('');
        }

	    $('.calculate-sub', tr).val(subtotal.toFixed(2));
	}

	function calculateTotal() {
	    
	    var grandTotal = 0,
	    	disc = 0,
	    	c_ship = parseInt($('.calculate.shipping').val()) || 0;

	    $('#class_tables tbody tr').each(function() {
            var c_sbt = $('.calculate-sub', this).val(),
                quantity = $('[name="invoice_product_qty[]"]', this).val(),
	            price = $('[name="invoice_product_price[]"]', this).val() || 0,
                subtotal = parseInt(quantity) * parseFloat(price);
            
            grandTotal += parseFloat(c_sbt);
            disc += subtotal - parseFloat(c_sbt);
	    });

        // VAT, DISCOUNT, SHIPPING, TOTAL, SUBTOTAL:
	    var subT = parseFloat(grandTotal),
	    	finalTotal = parseFloat(grandTotal + c_ship),
	    	vat = parseInt($('.invoice-vat').attr('data-vat-rate'));

	    $('.invoice-sub-total').text(subT.toFixed(2));
	    $('#invoice_subtotal').val(subT.toFixed(2));
        $('.invoice-discount').text(disc.toFixed(2));
        $('#invoice_discount').val(disc.toFixed(2));

        if($('.invoice-vat').attr('data-enable-vat') === '1') {

	        if($('.invoice-vat').attr('data-vat-method') === '1') {
		        $('.invoice-vat').text(((vat / 100) * finalTotal).toFixed(2));
		        $('#invoice_vat').val(((vat / 100) * finalTotal).toFixed(2));
	            $('.invoice-total').text((finalTotal).toFixed(2));
	            $('#invoice_total').val((finalTotal).toFixed(2));
	        } else {
	            $('.invoice-vat').text(((vat / 100) * finalTotal).toFixed(2));
	            $('#invoice_vat').val(((vat / 100) * finalTotal).toFixed(2));
		        $('.invoice-total').text((finalTotal + ((vat / 100) * finalTotal)).toFixed(2));
		        $('#invoice_total').val((finalTotal + ((vat / 100) * finalTotal)).toFixed(2));
	        }
		} else {
			$('.invoice-total').text((finalTotal).toFixed(2));
			$('#invoice_total').val((finalTotal).toFixed(2));
		}

		// remove vat
    	if($('input.remove_vat').is(':checked')) {
	        $('.invoice-vat').text("0.00");
	        $('#invoice_vat').val("0.00");
            $('.invoice-total').text((finalTotal).toFixed(2));
            $('#invoice_total').val((finalTotal).toFixed(2));
	    }

	}
	

// login form
	$(document).bind('keypress', function(e) {
		e.preventDefault;
		
        if(e.keyCode==13){
            $('#btn-login').trigger('click');
        }
    });

	$(document).on('click','#btn-login', function(e){
		e.preventDefault();
		actionLogin();
	});


	   	// login function
	function actionLogin() {

		var errorCounter = validateForm();

		if (errorCounter > 0) {

		    $("#response").removeClass("alert-success").addClass("alert-warning").fadeIn();
		    $("#response .message").html("<center>Por favor insira os seus dados de acesso.</center>");
		   

		} else {

			var $btn = $("#btn-login").button("loading");

			jQuery.ajax({
				url: 'server/response.php',
				type: "POST",
				data: $("#login_form").serialize(), 
				dataType: 'json',
				success: function(data){
					
					$btn.button("reset");
                 
					if (data.status=="success")
					{
						$("#response .message").html("<center> <strong>" + data.status + "</strong>: " + data.message+"</center>");
					    $("#response").removeClass("alert-warning").addClass("alert-success").fadeIn();
					    $btn.button("reset");
						window.location = "dashboard.php";
					}
					else{
						$("#response .message").html("<center> " + data.message+"</center>");
						$("#response").removeClass("alert-success").addClass("alert-warning").fadeIn();
						$btn.button("reset");
						//$("html, body").animate({ scrollTop: $('body').offset().top }, 1000);
                           
					}
				},
				error: function(data){
					$("#response .message").html("<strong>" + data.status + "</strong>: " + data.message);
					$("#response").removeClass("alert-success").addClass("alert-warning").fadeIn();
					//$("html, body").animate({ scrollTop: $('body').offset().top }, 1000);
					$btn.button("reset");
				}

			});

		}
		
	}


	// fading out the alert label
	$("#sent_form input").keyup(function(){
        $(this).parent().removeClass("has-error"); 
		$("#response").fadeOut("slow");
    });	
	
$("#form_activiti input, textarea").keyup(function(){
        $(this).parent().removeClass("has-error"); 
		$("#response").fadeOut("slow");
    });	


	$('#sent_form').on('submit', function(e){

    e.preventDefault();
	var errorCounter = validateForm();
	if (errorCounter > 0) {

		    $("#response").removeClass("alert-success").addClass("alert-warning").fadeIn();
		    $("#response .message").html("<center>Por favor preencha os campos vazios.</center>");
		    $("html, body").animate({ scrollTop: $('body').offset().top }, 1000);

		} else {
          var $btn = $("#btn_register").button("loading");

			$.ajax({
				url: 'server/response.php',
				type: 'POST',
				data: new FormData(this),
				dataType: 'json',
				contentType: false,
    	        cache: false,
			    processData:false,
				success: function(data){
				     

					if(data.status=="success"){
                              
		                    $("#response .message").html("<center><img src='dist/icons/happy-256.png' style='width:25px;'> " + data.message+"</center>");
							$("#response").removeClass("alert-warning").addClass("alert-success").fadeIn();
							$("html, body").animate({ scrollTop: $('body').offset().top }, 1000);
							document.getElementById("sent_form").reset();
							
							 $btn.button("reset");
							 
							
					     }
					 else if(data.status=="email"){

                            $("#response .message").html("<center><img src='dist/icons/Warning.png' style='width:25px;'> " + data.message+"</center>");
							$("#response").removeClass("alert-success").addClass(" alert-warning").fadeIn();
							$("html, body").animate({ scrollTop: $('body').offset().top }, 1000);
							$btn.button("reset");
					}
					     
				},
				error: function(data){
					
							$("#response .message").html("<center> " + data.message+"</center>");
							$("#response").removeClass("alert-success").addClass(" alert-warning").fadeIn();
							$("html, body").animate({ scrollTop: $('body').offset().top }, 1000);
							$btn.button("reset");
				}

			});

}
});






	$('#select_rooms').on('submit', function(e){

    e.preventDefault();
	var errorCounter = validateForm();
	if (errorCounter > 0) {

		    $("#response").removeClass("alert-success").addClass("alert-warning").fadeIn();
		    $("#response .message").html("<center>Por favor preencha os campos vazios.</center>");
		    $("html, body").animate({ scrollTop: $('body').offset().top }, 1000);

		} else {

        	var $btn = $("#btn_register").button("loading");

			$.ajax({
				url: 'server/response.php',
				type: 'POST',
				data: new FormData(this),
				dataType: 'json',
				contentType: false,
    	        cache: false,
			    processData:false,
				success: function(data){
				     
					if(data.status=="success"){
                              
		                    $("#response .message").html("<center><img src='dist/icons/happy-256.png' style='width:25px;'> " + data.message+"</center>");
							$("#response").removeClass("alert-warning").addClass("alert-success").fadeIn();
							$("html, body").animate({ scrollTop: $('body').offset().top }, 1000);

							//sessionStorage.setItem('MID',data.mid);
							$("#resp").before().html("<a href='print.php?id="+data.id+"' target='_blank' class='btn btn-primary'>Imprimir Ficha </a> <a href='print_factura.php?id="+data.id+"' target='_blank' class='btn btn-primary'>Imprimir Factura </a> <a href='#' class='btn btn-primary dashboard_'>Sair</a>");
							$btn.button("reset");
							
							
					     }
					else{

                            $("#response .message").html("<center><img src='dist/icons/Warning.png' style='width:25px;'> " + data.message+"</center>");
							$("#response").removeClass("alert-success").addClass(" alert-warning").fadeIn();
							$("html, body").animate({ scrollTop: $('body').offset().top }, 1000);
							$btn.button("reset");
					    }
					
					     
				},
				error: function(data){
					
							$("#response .message").html("<center> " + data.message+"</center>");
							$("#response").removeClass("alert-success").addClass(" alert-warning").fadeIn();
							$("html, body").animate({ scrollTop: $('body').offset().top }, 1000);
							$btn.button("reset");
				}

			});

}
});



	$('#ocupar_quarto').on('submit', function(e){

    e.preventDefault();
	var errorCounter = validateForm();
	if (errorCounter > 0) {

		    $("#response").removeClass("alert-success").addClass("alert-warning").fadeIn();
		    $("#response .message").html("<center>Por favor preencha os campos vazios.</center>");
		    $("html, body").animate({ scrollTop: $('body').offset().top }, 1000);

		} else {
          var $btn = $("#btn_register").button("loading");

			$.ajax({
				url: 'server/response.php',
				type: 'POST',
				data: new FormData(this),
				dataType: 'json',
				contentType: false,
    	        cache: false,
			    processData:false,
				success: function(data){
				     

					if(data.status=="success"){
                              
		                    $("#response .message").html("<center><img src='dist/icons/happy-256.png' style='width:25px;'> " + data.message+"</center>");
							$("#response").removeClass("alert-warning").addClass("alert-success").fadeIn();
							$("html, body").animate({ scrollTop: $('body').offset().top }, 1000);
							$("#ocupar_quarto").before().html("<a href='print.php?id="+data.id+"' target='_blank' class='btn btn-primary'>Imprimir Ficha </a> <a href='print_factura.php?id="+data.id+"' target='_blank' class='btn btn-primary'>Imprimir Factura </a> <a href='#' class='btn btn-primary dashboard_'>Sair</a>");
							//document.getElementById("sent_form").reset();
							
							 $btn.button("reset");
							 
							
					     }

					 else{

                            $("#response .message").html("<center><img src='dist/icons/Warning.png' style='width:25px;'> " + data.message+"</center>");
							$("#response").removeClass("alert-success").addClass(" alert-warning").fadeIn();
							$("html, body").animate({ scrollTop: $('body').offset().top }, 1000);
							$btn.button("reset");
					}
					     
				},
				error: function(data){
					
							$("#response .message").html("<center> <img src='dist/icons/happy-256.png' style='width:25px;'>Quarto ocupado com sucesso</center>");
							$("#response").removeClass("alert-warning").addClass("alert-success").fadeIn();
							$("html, body").animate({ scrollTop: $('body').offset().top }, 1000);
							$("#ocupar_quarto").before().html("<a href='print.php?id="+data.id+"' target='_blank' class='btn btn-primary'>Imprimir Ficha </a> <a href='print_factura.php?id="+data.id+"' target='_blank' class='btn btn-primary'>Imprimir Factura </a> <a href='#' class='btn btn-primary dashboard_'>Sair</a>");
							$btn.button("reset");
							
				}

			});

}
});	



	$('#analises_form').on('submit', function(e){

    e.preventDefault();
	var errorCounter = validateForm();
	if (errorCounter > 0) {

		    $("#response").removeClass("alert-success").addClass("alert-warning").fadeIn();
		    $("#response .message").html("<center>Por favor preencha os campos vazios.</center>");
		    $("html, body").animate({ scrollTop: $('body').offset().top }, 1000);

		} else {
          var $btn = $("#btn_register").button("loading");

			$.ajax({
				url: 'server/response.php',
				type: 'POST',
				data: new FormData(this),
				dataType: 'json',
				contentType: false,
    	        cache: false,
			    processData:false,
				success: function(data){
				     

					if(data.status=="success"){
                              
		                    $("#response .message").html("<center><img src='dist/icons/happy-256.png' style='width:25px;'> " + data.message+"</center>");
							$("#response").removeClass("alert-warning").addClass("alert-success").fadeIn();
							$("html, body").animate({ scrollTop: $('body').offset().top }, 1000);
							//document.getElementById("sent_form").reset();
							
							 $btn.button("reset");
							 
							
					     }

					 else{

                            $("#response .message").html("<center><img src='dist/icons/Warning.png' style='width:25px;'> " + data.message+"</center>");
							$("#response").removeClass("alert-success").addClass(" alert-warning").fadeIn();
							$("html, body").animate({ scrollTop: $('body').offset().top }, 1000);
							$btn.button("reset");
					}
					     
				},
				error: function(data){
					
							$("#response .message").html("<center> <img src='dist/icons/happy-256.png' style='width:25px;'>Quarto ocupado com sucesso</center>");
							$("#response").removeClass("alert-warning").addClass("alert-success").fadeIn();
							$("html, body").animate({ scrollTop: $('body').offset().top }, 1000);
							$("#analises_form").before().html("<a href='print.php?id="+data.id+"' target='_blank' class='btn btn-primary'>Imprimir Ficha </a> <a href='print_factura.php?id="+data.id+"' target='_blank' class='btn btn-primary'>Imprimir Factura </a> <a href='#' class='btn btn-primary dashboard_'>Sair</a>");
							$btn.button("reset");
							
				}

			});

}
});	



$('#form_vacance').on('submit',function(e){
e.preventDefault();

var errorCounter = validateForm();
if (errorCounter > 0) {

            $("#response").removeClass("alert-success").addClass("alert-warning").fadeIn();
		    $("#response .message").html("<center>Por favor preencha os campos vazios.</center>");
		    $("html, body").animate({ scrollTop: $('body').offset().top }, 1000);

}
else{


           var $btn = $("#btn_vacancies").button("loading");

			$.ajax({
				url: 'server/response.php',
				type: 'POST',
				data: new FormData(this),
				dataType: 'json',
				contentType: false,
    	        cache: false,
			    processData:false,
				success: function(data){
				     
					if(data.status=="success"){
                              
		                    $("#response .message").html("<center> " + data.message+"</center>");
							$("#response").removeClass("alert-warning").addClass("alert-success").fadeIn();
							$("html, body").animate({ scrollTop: $('body').offset().top }, 1000);
							document.getElementById("form_vacance").reset();
							$btn.button("reset");
							 
							
					}
					 else{

                            $("#response .message").html("<center> " + data.message+"</center>");
							$("#response").removeClass("alert-success").addClass(" alert-warning").fadeIn();
							$("html, body").animate({ scrollTop: $('body').offset().top }, 1000);
							$btn.button("reset");
					}
					     
				},
				error: function(data){
					
							$("#response .message").html("<center> " + data.message+"</center>");
							$("#response").removeClass("alert-success").addClass(" alert-warning").fadeIn();
							$("html, body").animate({ scrollTop: $('body').offset().top }, 1000);
							$btn.button("reset");
				}

			});


}


});  




$('#form_email').on('submit',function(e){
e.preventDefault();

var errorCounter = validateForm();
if (errorCounter > 0) {

            $("#response").removeClass("alert-success").addClass("alert-warning").fadeIn();
		    $("#response .message").html("<center>Por favor preencha os campos vazios.</center>");
		    $("html, body").animate({ scrollTop: $('body').offset().top }, 1000);

}
else{


           var $btn = $("#btn_send").button("loading");

			$.ajax({
				url: 'server/response.php',
				type: 'POST',
				data: new FormData(this),
				dataType: 'json',
				contentType: false,
    	        cache: false,
			    processData:false,
				success: function(data){
				     
					if(data.status=="success"){
                              
		                    $("#response .message").html("<center> " + data.message+"</center>");
							$("#response").removeClass("alert-warning").addClass("alert-success").fadeIn();
							$("html, body").animate({ scrollTop: $('body').offset().top }, 1000);
							document.getElementById("form_email").reset();
							$btn.button("reset");
							 
							
					}
					 else{

                            $("#response .message").html("<center> " + data.message+"</center>");
							$("#response").removeClass("alert-success").addClass(" alert-warning").fadeIn();
							$("html, body").animate({ scrollTop: $('body').offset().top }, 1000);
							$btn.button("reset");
					}
					     
				},
				error: function(data){
					
							$("#response .message").html("<center> " + data.message+"</center>");
							$("#response").removeClass("alert-success").addClass(" alert-warning").fadeIn();
							$("html, body").animate({ scrollTop: $('body').offset().top }, 1000);
							$btn.button("reset");
				}

			});


}


});  

// update invoice
	$(document).on('click', "#action_update_invoice", function(e) {
		e.preventDefault();
		updateInvoice();
	});

   	function updateInvoice() {

   		var $btn = $("#action_update_invoice").button("loading");
   		//$("#update_invoice").find(':input:disabled').removeAttr('disabled');

        jQuery.ajax({

        	url: 'server/response.php',
            type: 'POST', 
            data: $("#update_invoice").serialize(),
            dataType: 'json', 
            success: function(data){
				$("#response .message").html("<center><strong>" + data.status + "</strong>: " + data.message+"</center>");
				$("#response").removeClass("alert-warning").addClass("alert-success").fadeIn();
				$("html, body").animate({ scrollTop: $('body').offset().top }, 1000);
				$btn.button("reset");
			},
			error: function(data){
				$("#response .message").html("<center><strong>Sucesso:</strong>: Factura actualizada com sucesso</center>");
				$("#response").removeClass("alert-warning").addClass("alert-success").fadeIn();
				$("html, body").animate({ scrollTop: $('body').offset().top }, 1000);
				$btn.button("reset");
				
			} 
    	});

   	}



	// create invoice
	$("#action_create_invoice").click(function(e) {
		e.preventDefault();
	    actionCreateInvoice();
	});


	function actionCreateInvoice(){

		var errorCounter = validateForm();

		if (errorCounter > 0) {
		    $("#response").removeClass("alert-success").addClass("alert-warning").fadeIn();
		    $("#response .message").html("<center>Por favor preencha os campos vazios</center>");
		    $("html, body").animate({ scrollTop: $('body').offset().top }, 1000);
		} else {

			var $btn = $("#action_create_invoice").button("loading");

			$.ajax({

				url: 'server/response.php',
				type: 'POST',
				data: $("#create_invoice").serialize(),
				dataType: 'json',
				success: function(data){
							$("#response .message").html("<strong>" + data.status + "</strong>: " + data.message);
							$("#response").removeClass("alert-success").addClass("alert-warning").fadeIn();
							$("html, body").animate({ scrollTop: $('body').offset().top }, 1000);
							$btn.button("reset");
				},
				error: function(data){	
						    $("#response .message").html("<center> Factura criada com sucesso </center>" );
							$("#response").removeClass("alert-warning").addClass("alert-success").fadeIn();
							$("html, body").animate({ scrollTop: $('body').offset().top }, 1000);
							$("#create_invoice").before().html("<a href='all_invoices.php' class='btn btn-primary'>Abrir Factura</a> <a href='dashboard.php' class='btn btn-primary'>Voltar</a>");
							$btn.button("reset");
				} 

			});
		}

	}
	

	$('#update_news').on('submit', function(e){

    e.preventDefault();
	var errorCounter = validateForm();
	if (errorCounter > 0) {

		    $("#response").removeClass("alert-success").addClass("alert-warning").fadeIn();
		    $("#response .message").html("<center>Por favor preencha os campos vazios</center>");
		    $("html, body").animate({ scrollTop: $('body').offset().top }, 1000);

		} else {
         var $btn = $("#btn_update").button("loading");

			$.ajax({
				url: 'server/response.php',
				type: 'POST',
				data: new FormData(this),
				dataType: 'json',
				contentType: false,
    	        cache: false,
			    processData:false,
				success: function(data){
				     
                              
		                    $("#response .message").html("<center><img src='dist/icons/happy-256.png' style='width:25px;'> " + data.message+"</center>");
							$("#response").removeClass("alert-warning").addClass("alert-success").fadeIn();
							$("html, body").animate({ scrollTop: $('body').offset().top }, 1000);
							//document.getElementById("form_news_post").reset();
							
							 $btn.button("reset");

				},
				error: function(data){
					
							$("#response .message").html("<center> " + data.message+"</center>");
							$("#response").removeClass("alert-success").addClass(" alert-warning").fadeIn();
							$("html, body").animate({ scrollTop: $('body').offset().top }, 1000);
							$btn.button("reset");
				}

			});

}
});





	$('#update_activities').on('submit', function(e){

    e.preventDefault();
	var errorCounter = validateForm();
	if (errorCounter > 0) {

		    $("#response").removeClass("alert-success").addClass("alert-warning").fadeIn();
		    $("#response .message").html("<center>Por favor preencha os campos vazios.</center>");
		    $("html, body").animate({ scrollTop: $('body').offset().top }, 1000);

		} else {
         var $btn = $("#btn_update").button("loading");

			$.ajax({
				url: 'server/response.php',
				type: 'POST',
				data: new FormData(this),
				dataType: 'json',
				contentType: false,
    	        cache: false,
			    processData:false,
				success: function(data){
				     
                              
		                    $("#response .message").html("<center><img src='dist/icons/happy-256.png' style='width:25px;'> " + data.message+"</center>");
							$("#response").removeClass("alert-warning").addClass("alert-success").fadeIn();
							$("html, body").animate({ scrollTop: $('body').offset().top }, 1000);
							//document.getElementById("form_news_post").reset();
							
							 $btn.button("reset");

				},
				error: function(data){
					
							$("#response .message").html("<center> " + data.message+"</center>");
							$("#response").removeClass("alert-success").addClass(" alert-warning").fadeIn();
							$("html, body").animate({ scrollTop: $('body').offset().top }, 1000);
							$btn.button("reset");
				}

			});

}
});




// delete customer
	$(document).on('click', ".delete-candidate", function(e) {
        e.preventDefault();

        var userId = 'action=delete_candidate&delete='+ $(this).attr('cand_id'); //build a post data structure
        var user = $(this);

	    $('#delete_candidate').modal({ backdrop: 'static', keyboard: false }).one('click', '#delete', function() {
			delete_news(userId);
			$(user).closest('tr').remove();
        });
   	});



	// delete customer
	$(document).on('click', ".desocupar", function(e) {
		
        e.preventDefault();
       // alert('ola');
        
        var userId = 'action=desocupar_quarto&delete='+ $(this).attr('quarto'); //build a post data structure
        var user = $(this);

			delete_news(userId);
			$(user).closest('tr').remove();
      


   	});




// delete activities
	$(document).on('click', ".delete-member", function(e) {
        e.preventDefault();

        var userId = 'action=delete_member&delete='+ $(this).attr('data-member'); //build a post data structure
        var user = $(this);

	    $('#delete_activities').modal({ backdrop: 'static', keyboard: false }).one('click', '#delete', function() {
			delete_news(userId);
			$(user).closest('tr').remove();
        });
   	});


// delete activities
	$(document).on('click', ".delete-users", function(e) {
        e.preventDefault();

        var userId = 'action=delete_users&delete='+ $(this).attr('data-member'); //build a post data structure
        var user = $(this);

	    $('#delete_activities').modal({ backdrop: 'static', keyboard: false }).one('click', '#delete', function() {
			delete_news(userId);
			$(user).closest('tr').remove();
        });
   	});


// delete vacancies
	$(document).on('click', ".delete-vacancies", function(e) {
        e.preventDefault();

        var userId = 'action=delete_vacancies&delete='+ $(this).attr('data-vacancies'); //build a post data structure
        var user = $(this);

	    $('#delete_activities').modal({ backdrop: 'static', keyboard: false }).one('click', '#delete', function() {
			delete_news(userId);
			$(user).closest('tr').remove();
        });
   	});







    // delete invoice
  $(document).on('click', ".delete-analises", function(e) {
        e.preventDefault();
      
       var invoiceId = 'action=delete_analises&delete='+ $(this).attr('data-invoice-id'); //build a post data structure
      var invoice = $(this);

     $('#delete_invoice').modal({ backdrop: 'static', keyboard: false }).one('click', '#delete', function() {
    
        var pass = $('#admin_password').val();
        

       if(pass==""){
         
            $("#responses .message").html("<center>Please insert the admin password</center>");
            $("#responses").removeClass("alert-success").addClass("alert-warning").fadeIn();
            $("html, body").animate({ scrollTop: $('body').offset().top }, 1000);

       }else{
         
         $.post('server/admin_password.php',{pass: pass},function(data){
        if(data==true){
          
           deleteInvoice(invoiceId);
               $(invoice).closest('tr').remove();
               $("#responses .message").html("<center>Análise eliminado com sucesso!</center>");
         	   $("#responses").removeClass("alert-warning").addClass("alert-success").fadeIn();
          	   $("html, body").animate({ scrollTop: $('body').offset().top }, 1000);
               $('#admin_password').val('');
           
        }else{
          
          	   $("#responses .message").html("<center>Incorrect password, please try again!</center>");
               $("#responses").removeClass("alert-success").addClass("alert-warning").fadeIn();
               $("html, body").animate({ scrollTop: $('body').offset().top }, 1000);
               $('#admin_password').val('');
        }
        
        
      });
      
      
      
       }
      
      
      
      
      
      
        });
    });








    // delete invoice
  $(document).on('click', ".delete-invoice", function(e) {
        e.preventDefault();
      
       var invoiceId = 'action=delete_invoice&delete='+ $(this).attr('data-invoice-id'); //build a post data structure
      var invoice = $(this);

     $('#delete_invoice').modal({ backdrop: 'static', keyboard: false }).one('click', '#delete', function() {
    
        var pass = $('#admin_password').val();
        

       if(pass==""){
         
            $("#response .message").html("<center>Please insert the admin password</center>");
            $("#response").removeClass("alert-success").addClass("alert-warning").fadeIn();
            $("html, body").animate({ scrollTop: $('#response').offset().top }, 1000);

       }else{
         
         $.post('server/admin_password.php',{pass: pass},function(data){
        if(data==true){
          
           deleteInvoice(invoiceId);
               $(invoice).closest('tr').remove();
               $('#admin_password').val('');
           
        }else{
          
          $("#response .message").html("<center>Incorrect password, please try again!</center>");
          $("#response").removeClass("alert-success").addClass("alert-warning").fadeIn();
          $("html, body").animate({ scrollTop: $('#response').offset().top }, 1000);
          
          $('#admin_password').val('');
        }
        
        
      });
      
      
      
       }
      
      
      
      
      
      
        });
    });


	// delete news
	$(document).on('click', ".delete_noticias", function(e) {
        e.preventDefault();

        var userId = 'action=delete_news&delete='+ $(this).attr('data-news-id'); //build a post data structure
        var user = $(this);

	    $('#delete_noticias').modal({ backdrop: 'static', keyboard: false }).one('click', '#delete', function() {
			delete_news(userId);
			$(user).closest('tr').remove();
        });
   	});



	// delete news
	$(document).on('click', ".delete_gallery", function(e) {
        e.preventDefault();

        var userId = 'action=delete_gallery&delete='+ $(this).attr('data-gallery-id'); //build a post data structure
        var user = $(this);

	    $('#delete_gallery').modal({ backdrop: 'static', keyboard: false }).one('click', '#delete', function() {
			delete_news(userId);
			$(user).closest('tr').remove();
        });
   	});



	
   	function deleteInvoice(invoiceId) {

        jQuery.ajax({

        	url: 'server/response.php',
            type: 'POST', 
            data: invoiceId,
            dataType: 'json', 
            success: function(data){
				$("#response .message").html("<center><strong>" + data.status + "</strong>: " + data.message+"</center>");
				$("#response").removeClass("alert-warning").addClass("alert-success").fadeIn();
				$("html, body").animate({ scrollTop: $('#response').offset().top }, 1000);
				$btn.button("reset");
			},
			error: function(data){
				$("#response .message").html("<center><strong>" + data.status + "</strong>: " + data.message+"</center>");
				$("#response").removeClass("alert-success").addClass("alert-warning").fadeIn();
				$("html, body").animate({ scrollTop: $('#response').offset().top }, 1000);
				$btn.button("reset");
			} 
    	});

   	}



	function delete_news(userId) {

        jQuery.ajax({

        	url: 'server/response.php',
            type: 'POST', 
            data: userId,
            dataType: 'json', 
            success: function(data){
				$("#responses .message").html("<center> <strong>" + data.status + "</strong>: " + data.message +"</center> ");
				$("#responses").removeClass("alert-warning").addClass("alert-success").fadeIn();
				$("html, body").animate({ scrollTop: $('body').offset().top }, 1000);
			},
			error: function(data){
				$("#responses .message").html("<strong>" + data.status + "</strong>: " + data.message);
				$("#responses").removeClass("alert-success").addClass("alert-warning").fadeIn();
				$("html, body").animate({ scrollTop: $('body').offset().top }, 1000);
			} 
    	});

   	}



	$('#form_news_post').on('submit', function(e){

    e.preventDefault();
	var errorCounter = validateForm();
	if (errorCounter > 0) {

		    $("#response").removeClass("alert-success").addClass("alert-warning").fadeIn();
		    $("#response .message").html("<center>Por favor preencha os campos vazios.</center>");
		    $("html, body").animate({ scrollTop: $('body').offset().top }, 1000);

		} else {
         var $btn = $("#btn_postnews").button("loading");

			$.ajax({
				url: 'server/response.php',
				type: 'POST',
				data: new FormData(this),
				dataType: 'json',
				contentType: false,
    	        cache: false,
			    processData:false,
				success: function(data){
				     
					if(data.status=="success"){
                              
		                    $("#response .message").html("<center><img src='dist/icons/happy-256.png' style='width:25px;'> " + data.message+"</center>");
							$("#response").removeClass("alert-warning").addClass("alert-success").fadeIn();
							$("html, body").animate({ scrollTop: $('body').offset().top }, 1000);
							document.getElementById("form_news_post").reset();
							
							 $btn.button("reset");
							 
							
					     }
					 else if(data.status=="title"){

                            $("#response .message").html("<center><img src='dist/icons/Warning.png' style='width:25px;'> " + data.message+"</center>");
							$("#response").removeClass("alert-success").addClass(" alert-warning").fadeIn();
							$("html, body").animate({ scrollTop: $('body').offset().top }, 1000);
							$btn.button("reset");
					}
					else{
                         $("#response .message").html("<center><img src='dist/icons/happy-256.png' style='width:25px;'> " + data.message+"</center>");
							$("#response").removeClass("alert-warning").addClass("alert-success").fadeIn();
							$("html, body").animate({ scrollTop: $('body').offset().top }, 1000);
                           $btn.button("reset");

					}
					     
				},
				error: function(data){
					
							$("#response .message").html("<center> " + data.message+"</center>");
							$("#response").removeClass("alert-success").addClass(" alert-warning").fadeIn();
							$("html, body").animate({ scrollTop: $('body').offset().top }, 1000);
							$btn.button("reset");
				}

			});

}
});





$('#analises_form______').on('submit', function(e){
//var domy;
 e.preventDefault();

 //var $btn = $("#btn_users").button("loading");
var cboxes = document.getElementsByName('descricao[]');
    var len = cboxes.length;
    var action = "marcar_exames";
    var service = $('.servico').val();
    //var date = $('.date').val();
    //var hora = $('.hora').val();  
    // sessionStorage.clear();
    var member = $('.member').val();
    sessionStorage.setItem('MID',member);
  
   // var consulta = $('.consulta').val();
    for (var i=0; i<=len; i++) {
    
       if(cboxes[i].checked)  
      {

      	//	alert(cboxes[i].value);
       
              $.post('server/response.php',{descricao:cboxes[i].value, service:service, member:member, action:action}, function(data){

              		 //alert(data);
              		 if (data) {
              		 	//alert(data);
              		 	//sessionStorage.setItem('idp',data);

              		 	$("#response .message").html("<center><img src='dist/icons/happy-256.png' style='width:25px;'> Analises marcado com sucesso</center> ").show();
						$("#response").removeClass("alert-warning").addClass("alert-success").fadeIn();
						$("html, body").animate({ scrollTop: $('body').offset().top }, 1000);
						$("#msg").html("<a href='invoice-create.php?id="+data+"' class='btn btn-primary'>Criar Factura</a> <a href='dashboard.php' class='btn btn-primary'>Sair</a>");
              		
              		}



              }); 

              				//var domy =  sessionStorage.getItem("idp");


              				
      						
							//document.getElementById("form_users").reset();
                          	//$btn.button("reset");
      }
    else 
    {
         
        // $("html, body").animate({ scrollTop: $('body').offset().top }, 1000);    
       //$("#alert").text('Lista de chamada enserida com sucesso !').show().css('color', 'green');
      //   alert(cboxes[i].value);


    }

 

  
}



							
});







	$('#form_users').on('submit', function(e){

    e.preventDefault();
	var errorCounter = validateForm();
	if (errorCounter > 0) {

		    $("#response").removeClass("alert-success").addClass("alert-warning").fadeIn();
		    $("#response .message").html("<center>Por favor preencha os campos vazios.</center>");
		    $("html, body").animate({ scrollTop: $('body').offset().top }, 1000);

		} else {
         var $btn = $("#btn_users").button("loading");

			$.ajax({
				url: 'server/response.php',
				type: 'POST',
				data: new FormData(this),
				dataType: 'json',
				contentType: false,
    	        cache: false,
			    processData:false,
				success: function(data){
				     
					if(data.status=="success"){
                              
		                    $("#response .message").html("<center><img src='dist/icons/happy-256.png' style='width:25px;'> " + data.message+"</center>");
							$("#response").removeClass("alert-warning").addClass("alert-success").fadeIn();
							$("html, body").animate({ scrollTop: $('body').offset().top }, 1000);
							//sessionStorage.setItem('MID',data.id);
							$("#form_us").before().html("<a href='#' rel="+data.id+" class='btn btn-primary select_quarto'>Selecionar Quarto</a> <a href='#' class='btn btn-primary '>Sair</a>");
							//document.getElementById("form_users").reset();
							
							 $btn.button("reset");
							 
							
					     }
					 else if(data.status=="username"){

                            $("#response .message").html("<center><img src='dist/icons/Warning.png' style='width:25px;'> " + data.message+"</center>");
							$("#response").removeClass("alert-success").addClass(" alert-warning").fadeIn();
							$("html, body").animate({ scrollTop: $('body').offset().top }, 1000);
							$btn.button("reset");
					}
					else{
                         $("#response .message").html("<center><img src='dist/icons/happy-256.png' style='width:25px;'> " + data.message+"</center>");
							$("#response").removeClass("alert-success").addClass(" alert-warning").fadeIn();
							$("html, body").animate({ scrollTop: $('body').offset().top }, 1000);
                           $btn.button("reset");

					}
					     
				},
				error: function(data){
					
							$("#response .message").html("<center> " + data.message+"</center>");
							$("#response").removeClass("alert-success").addClass(" alert-warning").fadeIn();
							$("html, body").animate({ scrollTop: $('body').offset().top }, 1000);
							$btn.button("reset");
				}

			});

}
});


	$('#form_update_room').on('submit', function(e){

    e.preventDefault();
	var errorCounter = validateForm();
	if (errorCounter > 0) {

		    $("#response").removeClass("alert-success").addClass("alert-warning").fadeIn();
		    $("#response .message").html("<center>Por favor preencha os campos vazios.</center>");
		    $("html, body").animate({ scrollTop: $('body').offset().top }, 1000);

		} else {
         var $btn = $("#btn_users").button("loading");

			$.ajax({
				url: 'server/response.php',
				type: 'POST',
				data: new FormData(this),
				dataType: 'json',
				contentType: false,
    	        cache: false,
			    processData:false,
				success: function(data){
				     
					if(data.status=="success"){
                              
		                    $("#response .message").html("<center><img src='dist/icons/happy-256.png' style='width:25px;'> " + data.message+"</center>");
							$("#response").removeClass("alert-warning").addClass("alert-success").fadeIn();
							$("html, body").animate({ scrollTop: $('body').offset().top }, 1000);
							//sessionStorage.setItem('MID',data.id);
							$("#form_us").before().html("<a href='free_rooms.php' class='btn btn-primary'>Voltar</a>");
							//document.getElementById("form_users").reset();
							
							 $btn.button("reset");
							 
							
					     }
					else{
                         $("#response .message").html("<center><img src='dist/icons/happy-256.png' style='width:25px;'> " + data.message+"</center>");
							$("#response").removeClass("alert-success").addClass(" alert-warning").fadeIn();
							$("html, body").animate({ scrollTop: $('body').offset().top }, 1000);
                           $btn.button("reset");

					}
					     
				},
				error: function(data){
					
							$("#response .message").html("<center> " + data.message+"</center>");
							$("#response").removeClass("alert-success").addClass(" alert-warning").fadeIn();
							$("html, body").animate({ scrollTop: $('body').offset().top }, 1000);
							$btn.button("reset");
				}

			});

}
});


	$('#fecho_caixa').on('submit', function(e){

    e.preventDefault();
	var errorCounter = validateForm();
	if (errorCounter > 0) {

		    $("#response").removeClass("alert-success").addClass("alert-warning").fadeIn();
		    $("#response .message").html("<center>Por favor preencha os campos vazios.</center>");
		    $("html, body").animate({ scrollTop: $('body').offset().top }, 1000);

		} else {
         var $btn = $("#btn_users").button("loading");

			$.ajax({
				url: 'server/response.php',
				type: 'POST',
				data: new FormData(this),
				dataType: 'json',
				contentType: false,
    	        cache: false,
			    processData:false,
				success: function(data){
				     
					if(data.status=="success"){
                              
		                    $("#response .message").html("<center><img src='dist/icons/happy-256.png' style='width:25px;'> " + data.message+"</center>");
							$("#response").removeClass("alert-warning").addClass("alert-success").fadeIn();
							$("html, body").animate({ scrollTop: $('body').offset().top }, 1000);
							sessionStorage.setItem('MID',data.id);
							$("#fechando_caixa").before().html("<a href='caixa.php' class='btn btn-primary'>Visualizar</a> <a href='dashboard.php' class='btn btn-primary'>Sair</a>");
							//document.getElementById("form_users").reset();
							 $btn.button("reset");
							 
							
					     }
					 else if(data.status=="username"){

                            $("#response .message").html("<center><img src='dist/icons/Warning.png' style='width:25px;'> " + data.message+"</center>");
							$("#response").removeClass("alert-success").addClass(" alert-warning").fadeIn();
							$("html, body").animate({ scrollTop: $('body').offset().top }, 1000);
							$btn.button("reset");
					}
					else{
                         $("#response .message").html("<center><img src='dist/icons/happy-256.png' style='width:25px;'> " + data.message+"</center>");
							$("#response").removeClass("alert-success").addClass(" alert-warning").fadeIn();
							$("html, body").animate({ scrollTop: $('body').offset().top }, 1000);
                           $btn.button("reset");

					}
					     
				},
				error: function(data){
					
							$("#response .message").html("<center> " + data.message+"</center>");
							$("#response").removeClass("alert-success").addClass(" alert-warning").fadeIn();
							$("html, body").animate({ scrollTop: $('body').offset().top }, 1000);
							$btn.button("reset");
				}

			});

}
});


	$('#form_caixa').on('submit', function(e){

    e.preventDefault();
	var errorCounter = validateForm();
	if (errorCounter > 0) {

		    $("#response").removeClass("alert-success").addClass("alert-warning").fadeIn();
		    $("#response .message").html("<center>Por favor preencha os campos vazios.</center>");
		    $("html, body").animate({ scrollTop: $('body').offset().top }, 1000);

		} else {
         var $btn = $("#btn_users").button("loading");

			$.ajax({
				url: 'server/response.php',
				type: 'POST',
				data: new FormData(this),
				dataType: 'json',
				contentType: false,
    	        cache: false,
			    processData:false,
				success: function(data){
				     
					if(data.status=="success"){
                              
		                    $("#response .message").html("<center><img src='dist/icons/happy-256.png' style='width:25px;'> " + data.message+"</center>");
							$("#response").removeClass("alert-warning").addClass("alert-success").fadeIn();
							$("html, body").animate({ scrollTop: $('body').offset().top }, 1000);
							$("#form_caixa__").before().html("<a href='close_report.php?id="+data.id+"' target='_blank' class='btn btn-primary'>IMPRIMIR RELATÓRIO</a> <a href='dashboard.php' class='btn btn-primary'>SAIR</a>");
							//document.getElementById("form_users").reset();
							
							 $btn.button("reset");	 
							
					     }
					 else if(data.status=="username"){

                            $("#response .message").html("<center><img src='dist/icons/Warning.png' style='width:25px;'> " + data.message+"</center>");
							$("#response").removeClass("alert-success").addClass(" alert-warning").fadeIn();
							$("html, body").animate({ scrollTop: $('body').offset().top }, 1000);
							$btn.button("reset");
					}
					else{
                         $("#response .message").html("<center><img src='dist/icons/happy-256.png' style='width:25px;'> " + data.message+"</center>");
							$("#response").removeClass("alert-success").addClass(" alert-warning").fadeIn();
							$("html, body").animate({ scrollTop: $('body').offset().top }, 1000);
                           $btn.button("reset");

					}
					     
				},
				error: function(data){
					
							$("#response .message").html("<center> " + data.message+"</center>");
							$("#response").removeClass("alert-success").addClass(" alert-warning").fadeIn();
							$("html, body").animate({ scrollTop: $('body').offset().top }, 1000);
							$btn.button("reset");
				}

			});

}
});





	$('#register_service').on('submit', function(e){

    e.preventDefault();
	var errorCounter = validateForm();
	if (errorCounter > 0) {

		    $("#response").removeClass("alert-success").addClass("alert-warning").fadeIn();
		    $("#response .message").html("<center>Por favor preencha os campos vazios.</center>");
		    $("html, body").animate({ scrollTop: $('body').offset().top }, 1000);

		} else {
         var $btn = $("#btn_users").button("loading");

			$.ajax({
				url: 'server/response.php',
				type: 'POST',
				data: new FormData(this),
				dataType: 'json',
				contentType: false,
    	        cache: false,
			    processData:false,
				success: function(data){
				     
					if(data.status=="success"){
                              
		                    $("#response .message").html("<center><img src='dist/icons/happy-256.png' style='width:25px;'> " + data.message+"</center>");
							$("#response").removeClass("alert-warning").addClass("alert-success").fadeIn();
							$("html, body").animate({ scrollTop: $('body').offset().top }, 1000);
							//document.getElementById("form_users").reset();
							
							// $btn.button("reset");
							 
							
					     }
					 else if(data.status=="username"){

                            $("#response .message").html("<center><img src='dist/icons/Warning.png' style='width:25px;'> " + data.message+"</center>");
							$("#response").removeClass("alert-success").addClass(" alert-warning").fadeIn();
							$("html, body").animate({ scrollTop: $('body').offset().top }, 1000);
							$btn.button("reset");
					}
					else{
                         $("#response .message").html("<center><img src='dist/icons/happy-256.png' style='width:25px;'> " + data.message+"</center>");
							$("#response").removeClass("alert-success").addClass(" alert-warning").fadeIn();
							$("html, body").animate({ scrollTop: $('body').offset().top }, 1000);
                           $btn.button("reset");

					}
					     
				},
				error: function(data){
					
							$("#response .message").html("<center> " + data.message+"</center>");
							$("#response").removeClass("alert-success").addClass(" alert-warning").fadeIn();
							$("html, body").animate({ scrollTop: $('body').offset().top }, 1000);
							$btn.button("reset");
				}

			});

}
});




// post gallery

	$('#form_gallery').on('submit', function(e){

    e.preventDefault();
	var errorCounter = validateForm();
	if (errorCounter > 0) {

		    $("#response").removeClass("alert-success").addClass("alert-warning").fadeIn();
		    $("#response .message").html("<center>Por favor preencha os campos vazios.</center>");
		    $("html, body").animate({ scrollTop: $('body').offset().top }, 1000);

		} else {

            var $btn = $("#btn_gallery").button("loading");

			$.ajax({
				url: 'server/response.php',
				type: 'POST',
				data: new FormData(this),
				dataType: 'json',
				contentType: false,
    	        cache: false,
			    processData:false,
				success: function(data){
				     
					if(data.status=="success"){
                              
		                    $("#response .message").html("<center><img src='dist/icons/happy-256.png' style='width:25px;'> " + data.message+"</center>");
							$("#response").removeClass("alert-warning").addClass("alert-success").fadeIn();
							$("html, body").animate({ scrollTop: $('body').offset().top }, 1000);
							document.getElementById("form_gallery").reset();
							
							 $btn.button("reset");
							 
							
					     }
					else{
                         $("#response .message").html("<center><img src='dist/icons/happy-256.png' style='width:25px;'> " + data.message+"</center>");
							$("#response").removeClass("alert-success").addClass(" alert-warning").fadeIn();
							$("html, body").animate({ scrollTop: $('body').offset().top }, 1000);

                            $btn.button("reset");

					}
					     
				},
				error: function(data){
					
							$("#response .message").html("<center> " + data.message+"</center>");
							$("#response").removeClass("alert-success").addClass(" alert-warning").fadeIn();
							$("html, body").animate({ scrollTop: $('body').offset().top }, 1000);

							$btn.button("reset");
				}

			});

}
});










$('#form_activiti').on('submit', function(e){

    e.preventDefault();
	var errorCounter = validateForm();
	if (errorCounter > 0) {

		    $("#response").removeClass("alert-success").addClass("alert-warning").fadeIn();
		    $("#response .message").html("<center>Por favor preencha os campos vazios.</center>");
		    $("html, body").animate({ scrollTop: $('body').offset().top }, 1000);

		} else {
         var $btn = $("#btn_activities").button("loading");

			$.ajax({
				url: 'server/response.php',
				type: 'POST',
				data: new FormData(this),
				dataType: 'json',
				contentType: false,
    	        cache: false,
			    processData:false,
				success: function(data){
				     
					if(data.status=="success"){
                              
		                    $("#response .message").html("<center><img src='dist/icons/happy-256.png' style='width:25px;'> " + data.message+"</center>");
							$("#response").removeClass("alert-warning").addClass("alert-success").fadeIn();
							$("html, body").animate({ scrollTop: $('body').offset().top }, 1000);
							document.getElementById("form_activiti").reset();
							
							 $btn.button("reset");
							 
							
					     }
					 else if(data.status=="title"){

                            $("#response .message").html("<center><img src='dist/icons/Warning.png' style='width:25px;'> " + data.message+"</center>");
							$("#response").removeClass("alert-success").addClass(" alert-warning").fadeIn();
							$("html, body").animate({ scrollTop: $('body').offset().top }, 1000);
							$btn.button("reset");
					}
					else{
                         $("#response .message").html("<center><img src='dist/icons/happy-256.png' style='width:25px;'> " + data.message+"</center>");
							$("#response").removeClass("alert-warning").addClass("alert-success").fadeIn();
							$("html, body").animate({ scrollTop: $('body').offset().top }, 1000);
                           $btn.button("reset");

					}
					     
				},
				error: function(data){
					
							$("#response .message").html("<center> " + data.message+"</center>");
							$("#response").removeClass("alert-success").addClass(" alert-warning").fadeIn();
							$("html, body").animate({ scrollTop: $('body').offset().top }, 1000);
							$btn.button("reset");
				}

			});

}
});




 // add new product row on invoice
    var cloned = $('#gallery_table tr:last').clone();
    $(".add-row").click(function(e) {
        e.preventDefault();
        cloned.clone().appendTo('#gallery_table'); 
    });


	// remove product row
    $('#gallery_table').on('click', ".delete-row", function(e) {
    	e.preventDefault();
       	$(this).closest('tr').remove();
      
    });


 // add new product row on invoice
    var cloned = $('#invoice_table tr:last').clone();
    $(".add-rowsss").click(function(e) {
        e.preventDefault();
        cloned.clone().appendTo('#invoice_table'); 
        updateTotals(this);
	    calculateTotal();
    });
	
	
	// remove product row
    $('#invoice_table').on('click', ".delete-rowsss", function(e) {
    	e.preventDefault();
       	$(this).closest('tr').remove();
       	updateTotals(this);
	    calculateTotal();
        
    });




   	function validateForm() {
	    // error handling
	    var errorCounter = 0;

	    $(".required").each(function(i, obj) {

	        if($(this).val() === ''){
	            $(this).parent().addClass("has-error");
	            errorCounter++;
	        } else{ 
	            $(this).parent().removeClass("has-error"); 
	        }


	    });

	    return errorCounter;
	}

	
	
		


	
});