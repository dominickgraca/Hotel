//sessionStorage.setItem("id","12"); 
$(document).on('submit','form',function(e){
e.preventDefault();


// getting the users session id
var user = sessionStorage.getItem("id"); 

if (user) {

var action_post = "fetch_username";
var id_n = $(this).attr('class');
var id_news = $(this).attr('id');
var comment = $('#comment'+id_n+'').val();
var action = "post_comment";

// creating the method post
$.post('server/response.php',{action:action_post,id:user}, function(json){
$.each(json.result,function(i,dat){

  $('#postes'+id_n+'').append('<div class="comment_wrap"><div class="gravatar"><img src="images/blog/people_img.jpg" alt="" /></div><div class="comment_content"><div class="comment_meta"><div class="comment_author">'+dat.name+'-<i >Just now</i></div> </div><div class="comment_text"><p>'+comment+'</p> </div></div></div><!-- end section -->'); 
  $('#postes'+id_n+'').scrollTop(1000);

});

},'json');

// posting the comment to the server
 $.post('server/response.php',{action:action,comment:comment,id_news:id_news,id:user});
// clearing the form comment
 $('#comment'+id_n+'').val('');


}
else{

// alert if the user is not loged yet
alert('You are not a registered member please register');



}




 


});

