<?php 

include_once('server/session.php');
include_once('server/config.php');
include('server/functions.php');

$user= $_SESSION['user_afro'];
$sql = "SELECT * FROM usuarios WHERE username='$user' ";
$result = $mysqli->query($sql);
$row = $result->fetch_assoc();

?>

    <section class="content-header">
      <h1> 
      <ol class="breadcrumb">
        <li><a href="#" id="dashboard_"><i class="fa fa-home"></i> HOME</a></li>
        <li class="active">QUARTOS VAGOS</a></li>
      </ol>
      </h1>
        <ul class="nav nav-tabs">
            <li class="active"><a data-toggle="tab" href="#menu1">VISUALIZAR</a></li>
          <li><a data-toggle="tab" href="#register_news">CADASTRAR</a></li>
        </ul>
    </section>

  <div class="tab-content">
<div id="menu1" class="tab-pane fade in active">

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
 <div id="responses" class="alert alert-success" style="display:none;">
  <div class="message"></div>
  
</div>
          <!-- /.box -->

          <div class="box" >
            <div class="box-header" style="background-color: #dd4b39">
              <center><h3 class="box-title" style="color:white"> </h3></center>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <?php get_free_rooms(); ?>
    
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
    </div>
<div id="register_news" class="tab-pane fade">

    <section class="content">
      <div class="row">
        <!-- left column -->
        <div class="col-md-12">


 <div id="response" class="alert alert-success" style="display:none;">
  <div class="message"></div>
  
</div>
<div class="col-md-12" id="resp"> 
  <!-- general form elements -->
          <div class="box " >
            <div class="box-header with-border" style="background-color:#DD4B39">
              <h3 class="box-title" style="color:white">OCUPAR QUARTO</h3>
            </div>
            <!-- /.box-header -->
            <!-- form start -->
            <form  id="ocupar_quarto" name="ocupar_quarto" method="POST">
            
                  <div class="box-body">
                      <input type="hidden" name="action" value="ocupar_quarto">
                  <div class="col-md-12"> 
        <!-- Table row -->
      <div class="row">
      <div class="col-sm-2 ">
         <button type="button" class="btn btn-default add-rows" id="add_row"><i class="fa fa-plus-square"> </i> AD CAMPO</button>
      </div>
     
      <div class="col-sm-2 ">
         <input type="number" name="valor" class="form-control" placeholder="Valor" style="width:120px">
      </div>

      <select class="form-control" style="width:200px" id="metodo" name="metodo">
          <option>Metodo de Pagamento</option>
          <option>Dinheiro</option>
          <option>Cartão de Crédito</option>
      </select>

      

        <div class="col-xs-12 table-responsive">
                      <table class="table table-striped" id="class_tables">

            <thead>
                <tr>
                  <th>NOME DO CLIENTE</th>
                  <th>QUARTO Nº</th>
                  <th>DATA DE SAIDA</th>
                  <th>HORA DE ENTRADA</th>
                  <th>HORA DE SAIDA</th>
                </tr>
             
            </thead>

            <tbody>

              <tr>
                <td>
                    <div class="input-group ">

                       <div class="input-group-btn">
                           <button type="button" class="btn btn-danger delete-rows"><i class="fa fa-minus"></i></button>
                        </div>
                        
                                                             <?php  
                                                    			
                                                    			$company = $_SESSION['company'];
                                                              // the query
                                                              $query = "SELECT * FROM cliente WHERE company_id='$company' ORDER BY nome ASC";

                                                              // mysqli select query
                                                              $results = $mysqli->query($query);
                                                                                         
                                                                echo '<select class="form-control required" name="cli_id[]" style="width: 300px; margin-right:-50px">
                                                                         <option value="">Nome</option>';
                                                                      
                                                                    while($row = $results->fetch_assoc()) {

                                                                          print '<option value="'.$row['id'].'" >'.$row["nome"].' </option>';

                                                                      }

                                                                echo '</select>';
                                                              ?>
                                      
                    </div>
                </td>
                 <td>
                    <div class="input-group no-margin">

                      
                        
                                                             <?php  
                                                    $company = $_SESSION['company'];
                                                              // the query
                                                              $query = "SELECT * FROM quartos WHERE status='0' AND company_id='$company' ORDER BY numero ASC";

                                                              // mysqli select query
                                                              $results = $mysqli->query($query);
                                                                                         
                                                                echo '<select class="form-control required" name="qua_id[]" style="width: 110px;">
                                                                         <option value="">Número</option>';
                                                                      
                                                                    while($row = $results->fetch_assoc()) {

                                                                      print '<option value="'.$row['id'].'" >'.$row["numero"].' </option>';

                                                                      }

                                                                echo '</select>';
                                                              ?>
                                      
                    </div>
                </td>

                <td>
                    <div class="input-group no-margin">
                 
                      <input type="date" name="date_out[]" class="form-control required" style="width: 170px ">
                                      
                    </div>
                </td>
                 <td>
                    <div class="input-group no-margin">
                 
                        <input type="time" name="time_in[]" class="form-control required" style="width: 140px">
                                      
                    </div>
                </td>
                 <td>
                    <div class="input-group no-margin">
                 
                        <input type="time" name="time_out[]" class="form-control required" style="width: 120px">
                                      
                    </div>
                </td>   
              </tr>
            </tbody>
          </table>
                              <div class="box-footer">
                                <button type="submit" id="btn_register" class="btn btn-primary pull-right">OCUPAR</button>
                              </div>
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
                </div>        
                  </div>
                      </div>
                      
                  </div>              
            </form>
          </div>
        </div>  
        </div>
        </div>
      </section>
</div>
</div>
</div>

<div id="delete_invoice" class="modal fade">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
       <center> <h4 class="modal-title">APAGAR ANALISE</h4></center>
      </div>
      <div class="modal-body">
        <p>POR FAVOR DIGITE A SENHA DO ADMINISTRADOR !</p>
    
    <input type="password" class="form-control " name="admin_password" id="admin_password" /> 
    
      </div><br><br>
      <div class="modal-footer">
        <button type="button" data-dismiss="modal" class="btn btn-primary" id="delete">APAGAR</button>
       <button type="button" data-dismiss="modal" class="btn">CANCELAR</button>
      </div>
    </div><!-- /.modal-content -->
  </div><!-- /.modal-dialog -->
</div><!-- /.modal -->





<script src="plugins/jQuery/jquery-2.2.3.min.js"></script>
<script src="js/scripts.js"></script>
<!-- Bootstrap 3.3.7 -->
<script src="bootstrap/js/bootstrap.min.js"></script>
<!-- DataTables -->
<script src="plugins/datatables/jquery.dataTables.min.js"></script>
<script src="plugins/datatables/dataTables.bootstrap.min.js"></script>
<!-- SlimScroll -->
<script src="plugins/slimScroll/jquery.slimscroll.min.js"></script>
<!-- FastClick -->
<script src="plugins/fastclick/fastclick.js"></script>
<!-- AdminLTE App -->
<script src="dist/js/app.min.js"></script>
<script src="js/pagination.js"></script>

<script src="bootstrap/js/bootstrap.min.js"></script>
<!-- Select2 -->
<!-- page script -->
<script>
  $(function () {
    $("#example1").DataTable();
   
  });
</script>


<script type="text/javascript">
	
            $('.servico').on('change',function(){

                    var service = $(this).val();
                    var action  = "fetch_servico";

                    $.post('server/response.php',{action:action,service:service},function(json){
                      $('#description').html('');
						        $.each(json.result,function(i,dat){ 
                    
                    $('#description').append('<label><input type="checkbox" name="descricao[]" value="'+dat.id+'" class="flat-red" required> '+dat.name+' </label><br>');

                     });
 
                    },'json');

			})

</script>
