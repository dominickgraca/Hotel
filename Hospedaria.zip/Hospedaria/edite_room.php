<?php 

include_once('server/session.php');
include_once('server/config.php');
include('server/functions.php');

$user= $_SESSION['user_afro'];

$sql = "SELECT * FROM usuarios WHERE username='$user' ";
$result = $mysqli->query($sql);
$row = $result->fetch_assoc();

$id = $_GET['id'];

$query = "SELECT * FROM quartos WHERE id='$id'";
$results = $mysqli->query($query);
$rows = $results->fetch_assoc();

$numeros = $rows['numero'];
$preco = $rows['preco'];

?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>HOSPEDARIA HALAVALA</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <!-- Bootstrap 3.3.7 -->
  <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
  <!-- Font Awesome -->
<link rel="stylesheet" href="bootstrap/css/font-awesome.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="bootstrap/css/ionicons.min.css">
  <!-- DataTables -->
  <link rel="stylesheet" href="plugins/datatables/dataTables.bootstrap.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="dist/css/AdminLTE.min.css">
  <!-- AdminLTE Skins. Choose a skin from the css/skins
       folder instead of downloading all of them to reduce the load. -->
  <link rel="stylesheet" href="dist/css/skins/_all-skins.min.css">

  <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
  <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
  <!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
  <![endif]-->
</head>
<body class="skin-red sidebar-mini fixed sidebar-collapse">
<div class="wrapper">

  <header class="main-header" >
    <!-- Logo -->
    <a href="dashboard.php" class="logo">
      <!-- mini logo for sidebar mini 50x50 pixels -->
      <span class="logo-mini"><b>H</b></span>
      <!-- logo for regular state and mobile devices -->
   <span class="logo-lg"><b>HOSPEDARIA </b></span>
    </a>
    <!-- Header Navbar: style can be found in header.less -->
    <nav class="navbar navbar-static-top">
      <!-- Sidebar toggle button-->
      <a href="#" class="sidebar-toggle" data-toggle="offcanvas" role="button">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </a>

      <div class="navbar-custom-menu">
        <ul class="nav navbar-nav">
          <!-- User Account: style can be found in dropdown.less -->
          <li class="dropdown user user-menu">
             <a href="#" class="dropdown-toggle" data-toggle="dropdown">
              <!-- The user image in the navbar-->
              <img src="dist/img/avatar5.png" class="user-image" alt="User Image">
              <!-- hidden-xs hides the username on small devices so only the image appears. -->
               <span class="hidden-xs"><?php echo $_SESSION['user_afro']; ?></span>
            </a>
            <ul class="dropdown-menu">
              <!-- The user image in the menu -->
              <li class="user-header">
                <img src="dist/img/avatar5.png" class="img-circle" alt="User Image">

                 <p>
                 <?php echo $_SESSION['user_afro']; ?> 
                 <!-- <small>Member since Nov. 2012</small>-->
                </p>
              </li>
            
              <!-- Menu Footer-->
              <li class="user-footer">
                <div class="pull-left">
                  <a href="#" class="btn btn-default btn-flat" style="background-color: #00a65a; color: white">PERFIL</a>
                </div>
                <div class="pull-right">
                  <a href="logout.php" class="btn btn-default btn-flat" style="background-color: #00a65a; color: white">SAIR</a>
                </div>
              </li>
            </ul>
          </li>
          <!-- Control Sidebar Toggle Button -->
          <li>
            <a href="#" data-toggle="control-sidebar"><i class="fa fa-gears"></i></a>
          </li>
        </ul>
      </div>
    </nav>
  </header>
  <!-- Left side column. contains the logo and sidebar -->

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1> 
      <ol class="breadcrumb">
        <li><a href="dashboard.php"><i class="fa fa-home"></i> HOME</a></li>
        <li class="active">EDITAR QUARTO</a></li>
      </ol>
  </h1>
        <ul class="nav nav-tabs">
          <li class="active"><a data-toggle="tab" href="#register_news">Editar</a></li>
        </ul>
    </section>

  <div class="tab-content">

<div id="register_news" class="tab-pane fade in active">

    <section class="content">
      <div class="row">
        <!-- left column -->
        <div class="col-md-12">

 <div id="response" class="alert alert-success" style="display:none;">
  <div class="message"></div>
</div>
<div class="col-md-12" id="form_us"> 
  <!-- general form elements -->
          <div class="box" >
            <div class="box-header with-border" style="background-color:#dd4b39">
              <h3 class="box-title" style="color:white">CADASTRAR CLIENTE </h3>
            </div>
            <!-- /.box-header -->
            <!-- form start -->
            <form  id="form_update_room" name="form_update_room" method="post">
            
                    <div class="box-body">

                      <input type="hidden" name="action" value="update_room">
                        <input type="hidden" name="id" value="<?php echo $id; ?>">
                        <div class="col-md-6"> 

                                <div class="form-group">
                                  <label>NUMERO</label>
                                  <input type="text" class="form-control required" value="<?php echo $numeros; ?>" name="numero">
                                </div>
                              

                        </div>

                        <div class="col-md-6">

                            <div class="form-group">
                                <label> PRECO </label>
                              <input type="text" class="form-control" value="<?php echo $preco;?>" name="price">

                            </div>
                         

                        </div>

                            <br><br><br><br><br><br><br><br>
                            <div class="box-footer"> 
                             
                                <button type="submit" id="btn_users" class="btn btn-primary pull-right">ACTUALIZAR</button>
                            </div>
                  

                  </div>
                      </div>
                  </div>

                
            </form>
          </div>
        </div>

  
        </div>
        </div>
      </section>
</div>

</div>


</div>


      <div id="delete_activities" class="modal fade">
        <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header" >
          <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
          <center><h4 class="modal-title">Apagar Paciente</h4></center>
          </div>
          <div class="modal-body">

          <center> <p>Tens certesa?</p></center>
         
          </div>
          <div class="modal-footer">
          <button type="button" data-dismiss="modal" class="btn btn-primary" id="delete">Sim</button>
          <button type="button" data-dismiss="modal" class="btn">Não</button>
          </div>
        </div><!-- /.modal-content -->
        </div><!-- /.modal-dialog -->
      </div><!-- /.modal -->

 <footer class="main-footer ">
    <!-- To the right -->
    <div class="pull-right hidden-xs">
      Version 1.0
    </div>
    <!-- Default to the left -->
    <strong> Copyright © 2018 Hospedaria Halavala. All rights reserved by Graça Web.</strong>
  </footer>

  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Create the tabs -->
    <ul class="nav nav-tabs nav-justified control-sidebar-tabs">
      <li class="active"><a href="#control-sidebar-home-tab" data-toggle="tab"><i class="fa fa-home"></i></a></li>
      <li><a href="#control-sidebar-settings-tab" data-toggle="tab"><i class="fa fa-gears"></i></a></li>
    </ul>
    <!-- Tab panes -->
    <div class="tab-content">
      <!-- Home tab content -->
      <div class="tab-pane active" id="control-sidebar-home-tab">
        <h3 class="control-sidebar-heading">Recent Activity</h3>
        <ul class="control-sidebar-menu">
          <li>
            <a href="javascript:;">
              <i class="menu-icon fa fa-birthday-cake bg-red"></i>

              <div class="menu-info">
                <h4 class="control-sidebar-subheading">Langdon's Birthday</h4>

                <p>Will be 23 on April 24th</p>
              </div>
            </a>
          </li>
        </ul>
        <!-- /.control-sidebar-menu -->

        <h3 class="control-sidebar-heading">Tasks Progress</h3>
        <ul class="control-sidebar-menu">
          <li>
            <a href="javascript:;">
              <h4 class="control-sidebar-subheading">
                Custom Template Design
                <span class="pull-right-container">
                  <span class="label label-danger pull-right">70%</span>
                </span>
              </h4>

              <div class="progress progress-xxs">
                <div class="progress-bar progress-bar-danger" style="width: 70%"></div>
              </div>
            </a>
          </li>
        </ul>
        <!-- /.control-sidebar-menu -->

      </div>
      <!-- /.tab-pane -->
      <!-- Stats tab content -->
      <div class="tab-pane" id="control-sidebar-stats-tab">Stats Tab Content</div>
      <!-- /.tab-pane -->
      <!-- Settings tab content -->
      <div class="tab-pane" id="control-sidebar-settings-tab">
        <form method="post">
          <h3 class="control-sidebar-heading">General Settings</h3>

          <div class="form-group">
            <label class="control-sidebar-subheading">
              Report panel usage
              <input type="checkbox" class="pull-right" checked>
            </label>

            <p>
              Some information about this general settings option
            </p>
          </div>
          <!-- /.form-group -->
        </form>
      </div>
      <!-- /.tab-pane -->
    </div>
  </aside>

   <div class="control-sidebar-bg"></div>
</div>
<!-- ./wrapper -->

<!-- jQuery 2.2.3 -->
<script src="plugins/jQuery/jquery-2.2.3.min.js"></script>
<script src="js/scripts.js"></script>
<!-- Bootstrap 3.3.7 -->
<script src="bootstrap/js/bootstrap.min.js"></script>
<!-- DataTables -->
<script src="plugins/datatables/jquery.dataTables.min.js"></script>
<script src="plugins/datatables/dataTables.bootstrap.min.js"></script>
<!-- SlimScroll -->
<script src="plugins/slimScroll/jquery.slimscroll.min.js"></script>
<!-- FastClick -->
<script src="plugins/fastclick/fastclick.js"></script>
<!-- AdminLTE App -->
<script src="dist/js/app.min.js"></script>
<!-- AdminLTE for demo purposes -->

<!-- page script -->
<script>
  $(function () {
    $("#example1").DataTable();
   
  });
</script>
</body>
</html>
