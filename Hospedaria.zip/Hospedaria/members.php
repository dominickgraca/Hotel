<?php 

include_once('server/session.php');
include_once('server/config.php');
include('server/functions.php');

$user= $_SESSION['user_afro'];
$sql = "SELECT * FROM usuarios WHERE username='$user' ";
$result = $mysqli->query($sql);
$row = $result->fetch_assoc();

?>

    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1> 
      <ol class="breadcrumb">
        <li><a href="#" id="dashboard_"><i class="fa fa-home"></i> HOME</a></li>
        <li class="active">CLIÊNTES</a></li>
      </ol>
      </h1>
        <ul class="nav nav-tabs">
            <li class="active"><a data-toggle="tab" href="#menu1">VISUALIZAR</a></li>
          <li><a data-toggle="tab" href="#register_news">CADASTRAR</a></li>
        </ul>
    </section>

<div class="tab-content">
  <div id="menu1" class="tab-pane fade in active">

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
 <div id="responses" class="alert alert-success" style="display:none;">
  <div class="message"></div>
  
</div>
          <!-- /.box -->

          <div class="box" >
            <div class="box-header" style="background-color:#dd4b39">
              <center><h3 class="box-title" style="color:white"> </h3></center>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <?php getmembers(); ?>
    
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
    </div>
<div id="register_news" class="tab-pane fade">

    <section class="content">
      <div class="row">
        <!-- left column -->
        <div class="col-md-12">

 <div id="response" class="alert alert-success" style="display:none;">
  <div class="message"></div>
</div>
<div class="col-md-12" id="form_us"> 
  <!-- general form elements -->
          <div class="box" >
            <div class="box-header with-border" style="background-color:#dd4b39">
              <h3 class="box-title" style="color:white">CADASTRAR CLIENTE </h3>
            </div>
            <!-- /.box-header -->
            <!-- form start -->
            <form  id="form_users" name="form_users" method="post">
            
                    <div class="box-body">

                      <input type="hidden" name="action" value="create_cliente">
                        <div class="col-md-6"> 

                                <div class="form-group">
                                  <label> NOME COMPLETO * </label>
                                  <input type="text" class="form-control required" name="nome" placeholder="NOME COMPLETO">
                                </div>
                              
                                <div class="form-group">
                                  <label> NUMERO DO BILHETE * </label>
                                  <input type="text" class="form-control required" name="bi" placeholder="BI">
                                </div>     

                                <div class="form-group">
                                  <label> NACIONALIDADE</label>
                                  <input type="text" class="form-control" name="nacionalidade" placeholder="NACIONALIDADE">
                                </div>

                                <div class="form-group">
                                  <label> EMPREGO </label>
                                  <input type="text" class="form-control" name="emprego" placeholder="EMPREGO">
                                </div>

                                <div class="form-group">
                                  <label> E-mail </label>
                                  <input type="email" class="form-control" name="email" placeholder="E-mail">
                                </div>
                               
                        </div>

                        <div class="col-md-6">

                            <div class="form-group">
                                <label> GENERO * </label>
                                <select name="gender" class="form-control">
                                  <option value="MASCULINO"> MASCULINO </option>
                                  <option value="FEMENINO"> FEMENINO </option>
                                </select>

                            </div>
                         
                            <div class="form-group">
                              <label> TELEFONE </label>
                              <input type="text" class="form-control" name="mobile" placeholder="TELEFONE">
                            </div>
             
                            <div class="form-group">
                                  <label> PROVENIENCIA </label>
                                  <input type="text" class="form-control" name="proveniencia" placeholder="PROVENIENCIA">
                            </div>

                            <div class="form-group">
                                  <label> FUNÇÃO </label>
                                  <input type="text" class="form-control" name="funcao" placeholder="FUNÇÃO">
                            </div>
                              <div class="form-group">
                                  <label> INSERE AQUI COPIA DO BI </label>
                                  <input type="file" class="form-control" name="idcopy" accept="image/*">
                                 
                            </div>

                        </div>

                            <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
                            <div class="box-footer"> 
                             
                                <button type="submit" id="btn_users" class="btn btn-primary pull-right">CADASTRAR</button>
                            </div>
                  

                  </div>
                      </div>
                  </div>

                
            </form>
          </div>
        </div>

  
        </div>
        </div>
      </section>
</div>
</div>
</div>
      <div id="delete_activities" class="modal fade">
        <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header" >
          <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
          <center><h4 class="modal-title">Apagar Cliente</h4></center>
          </div>
          <div class="modal-body">

          <center> <p>Tens certesa?</p></center>
         
          </div>
          <div class="modal-footer">
          <button type="button" data-dismiss="modal" class="btn btn-primary" id="delete">Sim</button>
          <button type="button" data-dismiss="modal" class="btn">Não</button>
          </div>
        </div><!-- /.modal-content -->
        </div><!-- /.modal-dialog -->
      </div><!-- /.modal -->

<!-- ./wrapper -->

<!-- jQuery 2.2.3 -->
<script src="plugins/jQuery/jquery-2.2.3.min.js"></script>
<script src="js/scripts.js"></script>
<!-- Bootstrap 3.3.7 -->
<script src="bootstrap/js/bootstrap.min.js"></script>
<!-- DataTables -->
<script src="plugins/datatables/jquery.dataTables.min.js"></script>
<script src="plugins/datatables/dataTables.bootstrap.min.js"></script>
<!-- SlimScroll -->
<script src="plugins/slimScroll/jquery.slimscroll.min.js"></script>
<!-- FastClick -->
<script src="plugins/fastclick/fastclick.js"></script>
<!-- AdminLTE App -->
<script src="dist/js/app.min.js"></script>
<script src="js/pagination.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="bootstrap/js/bootstrap.min.js"></script>
<!-- page script -->
<script>
  $(function () {
    $("#example1").DataTable();
   
  });
</script>

